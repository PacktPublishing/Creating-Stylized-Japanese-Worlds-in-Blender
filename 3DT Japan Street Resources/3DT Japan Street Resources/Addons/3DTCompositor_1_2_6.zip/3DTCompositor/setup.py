import bpy
import addon_utils
import os
from .const import *
from .subpanel import CompositorSubpanel
from .preset import *
import json
import addon_utils

class Add3DTudorCompositorOperator(bpy.types.Operator):
    bl_idname = "object.3dt_add"
    bl_label = "Setup 3DT Compositor"

    apply_settings: bpy.props.BoolProperty(default=True)

    def append_data(self) -> bool:
        '''
        append node tree from nodetree.py + workspace
        '''

        # check if not appended yet
        if NODE_GROUP_NAME in bpy.data.node_groups and WORKSPACE_NAME in bpy.data.workspaces: 
            return True

        # find path of addon
        path = None
        for mod in addon_utils.modules():
            if mod.bl_info['name'] == ADDON_NAME:
                path = mod.__file__

        if path == None: return False

        # get folder
        folder = os.path.dirname(path)

        # create path to .blend file containing needed group
        blend_file = os.path.join(folder, NODE_GROUP_FILE)
        with bpy.data.libraries.load(blend_file) as (data_from, data_to):
            if NODE_GROUP_NAME in data_from.node_groups and WORKSPACE_NAME in data_from.workspaces:
                if not NODE_GROUP_NAME in bpy.data.node_groups:
                    bpy.ops.wm.append(filename=NODE_GROUP_NAME, directory=os.path.join(blend_file, "NodeTree", ""), check_existing=True)
                    print("Node Tree added successfully")
                else: return False
                if not WORKSPACE_NAME in bpy.data.workspaces:
                    bpy.ops.wm.append(filename=WORKSPACE_NAME, directory=os.path.join(blend_file, "WorkSpace", ""), check_existing=True)
                    print("Workspace added successfully")
                else: return False
                return True
        return False
    
    def setup_node_tree(self, context):
        '''
        Setup Compositor to use nodes, add Compositor node group and add all connections
        '''
        scene = bpy.data.scenes["Scene"]
        
        # get node tree
        if not scene.compositing_node_group:
            tree = bpy.data.node_groups.new(name="3DT Compositor", type="CompositorNodeTree")
            scene.compositing_node_group = tree
        
        node_tree = scene.compositing_node_group
        nodes = node_tree.nodes
        nodes.clear()

        # set cycles as render engine
        scene.render.engine = 'CYCLES'

        if self.apply_settings:
            scene.render.film_transparent = True
            scene.render.compositor_device = 'GPU'
            scene.cycles.device = 'GPU' 
            scene.cycles.tile_size = 2048
            scene.render.image_settings.file_format = "PNG"
            scene.render.image_settings.color_mode = "RGBA"

        # enable mist viewport info in all cameras
        for c in bpy.data.cameras:
            c.show_mist = True

        # add all needed nodes
        render_layers = nodes.new('CompositorNodeRLayers')
        render_layers.location.x = 0
        
        # group output
        output = nodes.new("NodeGroupOutput")
        output.location.x = 500
        
        # 3DT compositor node group
        comp_group = nodes.new('CompositorNodeGroup')
        comp_group.node_tree = bpy.data.node_groups[NODE_GROUP_NAME] 
        comp_group.location.x = 300
        
        # output viewer
        viewer = nodes.new("CompositorNodeViewer")
        viewer.location = (500, -120)
        
        # file output
        file_out = nodes.new('CompositorNodeOutputFile')
        file_out.mute = True
        file_out.location = (500, -240)
        file_out.file_output_items.new("RGBA", "Image") # add Image output

        # move all nodes right
        for n in nodes: n.location.x += 2000

        # add group outputs
        node_tree.interface.clear()
        node_tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")

        conn = node_tree.links

        # output connections
        conn.new(comp_group.outputs['Image Output'], output.inputs['Image'])
        # viewer connections
        conn.new(comp_group.outputs['Image Output'], viewer.inputs['Image'])
        # file out connection
        conn.new(comp_group.outputs['Emission Pass'], file_out.inputs['Image'])

        vl = scene.view_layers[0]
        
        # render layer -> 3DT comps connections
        # alpha
        conn.new(render_layers.outputs['Alpha'], comp_group.inputs['Alpha'])
        
        # mist
        vl.use_pass_mist = True
        conn.new(render_layers.outputs['Mist'], comp_group.inputs['Mist'])
        
        # diffuse
        vl.use_pass_diffuse_direct = True
        vl.use_pass_diffuse_indirect = True
        vl.use_pass_diffuse_color = True
        
        # DiffDir -> Diffuse Direct
        conn.new(render_layers.outputs['Diffuse Direct'], comp_group.inputs['Diff Direct'])
        # DiffInd -> Diffuse Indirect
        conn.new(render_layers.outputs['Diffuse Indirect'], comp_group.inputs['Diff Indirect'])
        # DiffCol -> Diffuse Color
        conn.new(render_layers.outputs['Diffuse Color'], comp_group.inputs['Diff Color'])
        
        # glossy
        vl.use_pass_glossy_direct = True
        vl.use_pass_glossy_indirect = True
        vl.use_pass_glossy_color = True
        
        # GlossDir -> Glossy Direct
        conn.new(render_layers.outputs['Glossy Direct'], comp_group.inputs['Gloss Direct'])
        # GlossInd -> Glossy Indirect
        conn.new(render_layers.outputs['Glossy Indirect'], comp_group.inputs['Gloss Indirect'])
        # GlossCol -> Glossy Color
        conn.new(render_layers.outputs['Glossy Color'], comp_group.inputs['Gloss Color'])
        
        # transmission
        vl.use_pass_transmission_direct = True
        vl.use_pass_transmission_indirect = True
        vl.use_pass_transmission_color = True
        
        # TransDir -> Transmission Direct
        conn.new(render_layers.outputs['Transmission Direct'], comp_group.inputs['Transmission Direct'])
        # TransInd -> Transmission Indirect
        conn.new(render_layers.outputs['Transmission Indirect'], comp_group.inputs['Transmission Indirect'])
        # TransCol -> Transmission Color
        conn.new(render_layers.outputs['Transmission Color'], comp_group.inputs['Transmission Color'])
        
        # volume
        vl.cycles.use_pass_volume_direct = True
        vl.cycles.use_pass_volume_indirect = True
        
        render_layers.update()
        
        # VolumeDir -> Volume Direct
        conn.new(render_layers.outputs['Volume Direct'], comp_group.inputs['Volume Direct'])
        # VolumeInd -> Volume Indirect
        conn.new(render_layers.outputs['Volume Indirect'], comp_group.inputs['Volume Indirect'])
        
        # emission
        vl.use_pass_emit = True
        # Emit -> Emission
        conn.new(render_layers.outputs['Emission'], comp_group.inputs['Emission'])
        
        # environment
        vl.use_pass_environment = True
        # Env -> Environment
        conn.new(render_layers.outputs['Environment'], comp_group.inputs['Environment'])
        
        # AO
        vl.use_pass_ambient_occlusion = True
        # AO -> Ambient Occlusion (Usually expanded, though AO might linger as an alias, safer to use full)
        conn.new(render_layers.outputs['Ambient Occlusion'], comp_group.inputs['AO'])

    def execute(self, context):
        if not self.append_data(): 
            self.report({'ERROR'}, 'Error while importing Compositor node group or Workspace.')
            return {'CANCELLED'}
        
        self.setup_node_tree(context)
        bpy.context.window.workspace = bpy.data.workspaces[WORKSPACE_NAME]
        self.report({'INFO'}, "3DT Compositor setup was successfull.")

        # set default background type to none
        props = context.scene.threedt_comp_props
        props.bg_type = "none"

        return {'FINISHED'}

    def draw(self, context):
        row = self.layout
        row.prop(self, "apply_settings", text="Apply Recommended Settings")
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)